package demoPackage;



public class OopConstructor {
	
	
	// A method that performs an action
	void method1()
	{
		System.out.println("Do Something");		

	}
	
	//Constructor to call method1
	public OopConstructor() {
		method1();
		
	}

		
	public static void main(String[] args) {
		//Create an object of OopConstructor Class
		
		OopConstructor Obj = new OopConstructor();
	}

}
