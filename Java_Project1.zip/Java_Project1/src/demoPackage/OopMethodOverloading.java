package demoPackage;

public class OopMethodOverloading {
	
	//Method with no parameters
	void method1()
	{
		System.out.println("method1 with no parameters");
	}
	
	void method1(int x) 
	{
		System.out.println("method1 with one parameter : " + x);
	}
	
	void method1(int x, String y)
	{
		System.out.println("method1 with 2 parameters : " + x + ", " + y);
	}	
	
		

	public static void main(String[] args) {
		
		//Create an object of the class			
		OopMethodOverloading obj = new OopMethodOverloading();
		
		//Call overLoaded methods		
		obj.method1(); // Calls the method with no parameters
		obj.method1(2); // Calls the method with one parameter
		obj.method1(2, " Overloading "); //	Calls the method with two parameters
		

	}

}
