package demoPackage;

interface CommonPerson{
	public abstract void getname();
}

public class OopInterfaceExample implements CommonPerson {
	
	private String name;
	String mobile;
	String password;
	int age;
	
	public void getname() {
				
	}

}


class Temp{
	void testMethod(CommonPerson p) {
		
		p.getname();
		
		
		
	}
}