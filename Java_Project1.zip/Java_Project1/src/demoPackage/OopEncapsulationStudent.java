package demoPackage;

public class OopEncapsulationStudent {
	
	private int id;
	private String name;
	private int age;
	
	//setter for id
	public void setId(int id){
		this.id = id;
	}
	//getter for id
	public int getId() {
		return id;
	}
	
	//setter for name
	public void setName(String name) {
		this.name = name;
	}
	
	//getter for name
	public String getName() {
		return name;
	}
	//setter for age
	public void setAge(int age) {
		
	}
	
	//getter for age
	public int getAge() {
		return age;
	}

}
class Demo{
	
	public static void Main(String args[]) {
		
		OopEncapsulationStudent s = new OopEncapsulationStudent();
		/*
		s.id = 1;
		s.name = "Sanda";
		s.age =20;
		*/
		
		s.setId(1);
		s.setName("Sanda");
		s.setAge(20);
		
		//Use getters to retrieve and display values
		
		System.out.println("Student Details: ");
		System.out.println("ID: " + s.getId());
		System.out.println("NAME: " + s.getName());
		System.out.println("AGE: " + s.getAge());
		
	}
	
}
