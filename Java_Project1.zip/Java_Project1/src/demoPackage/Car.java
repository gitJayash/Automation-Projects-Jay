package demoPackage;

public class Car {
	
	String color = "Black";
	int seats;
	int doors;
	
	void drive()
	{
		System.out.println("The Car is Driving");
	}
	
	void reverse()
	{
		System.out.println("The Car is reversing");
	}
	
	
	

	
	public static void main(String[] args) {
	/*
		Car myCar;
		myCar = new Car();
	*/	
		//Car myCar = new Car();
		
		//int x;
		//x=5;
		
		//myCar1.color
		
		
		Car myCar1 = new Car();
		Car myCar2 = new Car();
		Car myCar3 = new Car();
		
		myCar1.color = "Black";
		myCar1.doors = 4;
		myCar1.seats = 5;	
		
		
		//Print Car Details
		
		System.out.println("Car1 Color is : " + myCar1.color);
	}

}
