package demoPackage;

public class OopInheritance {
	
	private String brand = "Generic brand";
	String name = "Default phone";
	
	void messages() 
	{
		System.out.println("This is messaging feature");
	}
	
	void calls()
	{
		System.out.println("This is Calling feature");
	}
	
	public String getBrand() {
		return brand;	
	}
	
	
	
class NewPhone extends OopInheritance{
	
	int wifi = 1;
	int bluetooth = 2;
	
	void music()
	{
		System.out.println("T	his is music feature");
	}
	
	void video()
	{
		System.out.println("This is video feature");
	}
	
	void camera()
	
	{
		System.out.println("This is camera feature");
	}
	
		
}



	public static void main(String[] args) {
		
		//Create an object of the child class
		NewPhone phone1 = NewPhone();
		
		//Accesss Parent Class Methods
		phone1.calls();
		phone1.messages();
		
		//Access Child Class Methods
		phone1.music();
		phone1.video();
		phone1.camera();
		
		// Access inherited and additional properties
        System.out.println("Phone brand: " + phone1.getBrand());
        System.out.println("Phone name: " + phone1.name);
        System.out.println("WiFi version: " + phone1.wifi);
        System.out.println("Bluetooth version: " + phone1.bluetooth);

	}
	
}

