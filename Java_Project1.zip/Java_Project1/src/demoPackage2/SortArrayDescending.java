package demoPackage2;

import java.util.Arrays;

public class SortArrayDescending {

	public static void main(String[] args) {
		int[]arr = {12,3,7,9,30};
		Arrays.sort(arr);
		
		for(int i = 0; i<arr.length/2; i++) {
			
			int j = arr[i];
			arr[i] = arr[arr.length-1-i];
			arr[arr.length-1-i] = j;
		}
		
				
		System.out.println(Arrays.toString(arr));
		
		
	}

}
