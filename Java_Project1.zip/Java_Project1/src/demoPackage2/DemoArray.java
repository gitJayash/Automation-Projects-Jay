package demoPackage2;

public class DemoArray {
	
	
	int[] x = new int[3];
	
	public DemoArray() {
		x[0] = 30;
		x[1] = 91;
		x[2] = 21;
	}
	
	

	public static void main(String[] args) {
		
		DemoArray d = new DemoArray();
		System.out.println("First Index: " + d.x[0]);
		

	}

}
