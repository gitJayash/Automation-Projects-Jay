package demoPackage2;

import java.util.Arrays;

public class DemoArray2 {
	
	
	int[] numbers = {1,9,10,12,67,111};
	String[] letters = {"Kamal", "Nimal", "Sunil", "Jayantha"};
	
	
	public static void main(String[] args) {
		DemoArray2 d2 = new DemoArray2();
		
		System.out.println("1-----");
		System.out.println(d2.numbers[1]);
		
		System.out.println("2-----");
		System.out.println(d2.letters[3]);
		
		
		System.out.println("3-----");
		System.out.println(d2.numbers);
		System.out.println(d2.numbers.toString());
				
		
		
		//DemoArray2 d2 = new DemoArray2();
		System.out.println("4-----");
		System.out.println("Print Array: "+ Arrays.toString(d2.numbers));
		
		System.out.println("5-----");
		System.out.println("Print Array: "+ Arrays.toString(d2.letters));
		
		System.out.println("6-----");
		System.out.println(Arrays.toString(d2.numbers));

	}

}
