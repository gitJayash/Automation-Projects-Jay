package demoPackage2;

public class CountOccuranceEachCharacter {

	public static void main(String[] args) {
		

			int a = 10;
			int b = 20;
			
			int c = a;
			a = b;
			b = c;
			
			
		System.out.println("After swapping" + " a is " + a + " b is " + b);

	}

}
