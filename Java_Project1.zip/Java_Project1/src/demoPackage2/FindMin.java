package demoPackage2;

public class FindMin {

	public static void main(String[] args) {
		
		int[] numbers = {29,10,2,78,10,122,9,0,2};
		
		int min = numbers[0];
		
		for(int num: numbers) {
			
			if(num<min) {
				
				min=num;
			}
		}
		
		System.out.println("Lowest value in the array is : " + min);
		

	}

}
