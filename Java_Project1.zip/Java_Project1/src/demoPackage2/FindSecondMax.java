package demoPackage2;

public class FindSecondMax {

	public static void main(String[] args) {
		
		int[] numbers = {23,54,1,90,3,6,7,9};
		
		//int max = numbers[0];
		int max = Integer.MIN_VALUE;
		int secondMax = Integer.MIN_VALUE;
		
		for(int num : numbers) 
		{
			if(max<num) {
				secondMax = max;				
				max = num;
			}
			
			else if(num > secondMax && num != max ) {
				
				secondMax = max;	
			}
			
		}
		
		System.out.println(secondMax);

	}

}
