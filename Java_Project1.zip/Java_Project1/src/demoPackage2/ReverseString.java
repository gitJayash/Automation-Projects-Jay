package demoPackage2;

public class ReverseString {

	String reverseString;
	
	//Constructor to reverse the string
	public ReverseString(String input){
		
		StringBuilder sb = new StringBuilder(input);
		reverseString = sb.reverse().toString();
	}
	
	
	//Method to return the reversed string
	public String getReversedString() {
		return reverseString;
	}
	
		
	
	public static void main(String[] args) {
		
		//Input String
		String original = "Hello World!";
		
		//Create an object of reversing
		
		ReverseString reverseObj = new ReverseString(original);
		
		//Display the reversed String
		System.out.println("Original String:" + original);
		
		System.out.println("Reversed String:" + reverseObj.getReversedString());
		
		

	}

}
