package demoPackage2;

public class FindMax {

	public static void main(String[] args) {
		
		//define integer array
		int[]numbers = {23,45,71,99,2,12};
		
		//assume max value is first element of the integer
		int max = numbers[0];
		
		//compare numbers integer array assigning to new integer called num through a loop
		for(int num : numbers) {
			
			//create a condition if num greater than max, then max = num
			if(num>max) {
				max = num;
				
			}
		}
		System.out.println("The highest value is " + max);
	}

}
